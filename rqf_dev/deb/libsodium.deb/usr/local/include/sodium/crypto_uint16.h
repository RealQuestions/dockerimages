#ifndef crypto_uint16_H
#define crypto_uint16_H

#include <stdint.h>

typedef uint16_t crypto_uint16;

#endif
