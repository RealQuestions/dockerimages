cd projects/mongrel2
make clean all && sudo make install
