cd mongrel2
git pull

# make sure you get a clean build
make clean all

# install it once again
sudo make install
