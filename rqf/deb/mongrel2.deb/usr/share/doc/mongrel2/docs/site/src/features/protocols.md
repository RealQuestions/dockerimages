Supported Protocols
===================

Mongrel2 supports most of the recent web browser protocols without you
needing to change your backend code to support them.  It also has an
asynchronous design by default, which lets you do things other web
server can't handle like streaming a video from multiple backends after
other backends have received the request.

HTTP 1.1
========

Soon...

Flash Sockets
=============


Soon...

WebSockets (soon)
=================


Soon...

