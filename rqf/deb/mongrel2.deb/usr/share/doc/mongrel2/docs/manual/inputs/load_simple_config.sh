m2sh load -config examples/configs/sample.conf
ls -l config.sqlite
m2sh servers
m2sh hosts -server test
m2sh start -name test
