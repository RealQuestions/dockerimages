sudo procer $PWD $PWD/../run/procer.pid
less error.log
