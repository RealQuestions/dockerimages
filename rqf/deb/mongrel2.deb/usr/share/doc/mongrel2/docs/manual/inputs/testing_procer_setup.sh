curl http://localhost:6767/
# Hello, World!
curl http://localhost:6767/handlertest
