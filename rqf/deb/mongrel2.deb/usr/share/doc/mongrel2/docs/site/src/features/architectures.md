Supported Architectures
=======================

Mongrel2 is designed to fit into many network architectures.


More Stuff
==========

Coming soon.
