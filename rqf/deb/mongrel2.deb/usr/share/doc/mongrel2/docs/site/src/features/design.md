Modern Design
=============

Rather than bullshit you with lies about how callbacks are awesome and events
are the one true way to do everything, Mongrel2 tries to use whatever gets
the fastest web server with the least amount of code.  The server uses clear
easy to read C code (not C++), events for high-speed I/O, coroutines for simple
fast context switching, and threads through ZeroMQ for backend communication.


Clear Written C
===============

Soon...

Event Base I/O
==============


Soon...

Coroutines
==========


Soon...

Multi-Core Threads
==================


Soon...

Fast Logging
============


Soon...

